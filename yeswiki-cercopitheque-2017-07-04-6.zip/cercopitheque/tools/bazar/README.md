Bazar
=====

Gestionnaire de formulaire pour Yeswiki.

Bazar est une extension pour le wiki Yeswiki ( http://yeswiki.net ) permettant de générer des formulaires à l'intérieur d'une page wiki et permettant d'avoir des vues des données saisies (listes, cartographies, flux RSS, calendrier).