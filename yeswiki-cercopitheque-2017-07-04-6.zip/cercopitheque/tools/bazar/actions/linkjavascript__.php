<?php

if (!defined("WIKINI_VERSION")) {
            die ("acc&egrave;s direct interdit");
}

// plus utilisé car appelé par _linkjavascript.php
