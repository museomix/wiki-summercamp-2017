autoUpdate
=======================

Un tool pour automatiser la mise à jour de YesWiki.

L'action {{update}} permet d'afficher la version de YesWiki. Si
l'utilisateur connecté est un administrateur un bouton permet de lancer la mise
à jour du Wiki si une version plus récente est disponible.

Par défaut, le dépot est //http://yeswiki.net/repository// il est possible d'en
définir un autre en spécifiant le paramètre **'yeswiki_repository'** dans le
fichier wakka.config.php du Wiki.
