<?php

if (!defined("WIKINI_VERSION"))
{
            die ("acc&egrave;s direct interdit");
}

echo '	<link rel="stylesheet" href="tools/attach/presentation/styles/attach.css" />'."\n";

?>
