<?php
if (!defined('WIKINI_VERSION')) {
    die("acc&egrave;s direct interdit");
}

ob_end_flush();
?>
  <script src="tools/templates/libs/vendor/jquery-1.11.3.min.js"></script>
  <script src="tools/templates/libs/vendor/bootstrap.min.js"></script>
</body>
</html>
